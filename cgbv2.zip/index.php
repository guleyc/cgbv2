<!DOCTYPE html>
<html class="no-js" lang="<?php echo Theme::lang() ?>">
<head>
    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <?php echo Theme::metaTags('title') ?>
    <?php echo Theme::metaTags('description') ?>
    <meta name="author" content="çağatay güley">
    <meta name="generator" content="çağatay güley">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- CSS
    ================================================== -->
    <?php echo Theme::css('assets/css/bootstrap.min.css') ?>
	<?php echo Theme::css('assets/css/fontawesome.css') ?>
	<?php echo Theme::css('assets/css/slick.css') ?>
	<?php echo Theme::css('assets/css/style.css') ?>


    <!-- favicons
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo ($site->logo()?$site->logo():Theme::src('images/favicon.jpg')) ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo ($site->logo()?$site->logo():Theme::src('images/favicon.jpg')) ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ($site->logo()?$site->logo():Theme::src('images/favicon.jpg')) ?>">
    <link rel="manifest" href="<?php echo Theme::src('site.webmanifest') ?>">

	<!-- Load Bludit Plugins: Site head -->
	<?php Theme::plugins('siteHead') ?>
</head>
	<body>
	<!-- reading position indicator -->
    <progress value="0" id="cg-progress-bar">
        <span class="cg-progress-container">
            <span class="cg-progress-bar"></span>
        </span>
    </progress>
	<!-- site wrapper -->
    <div id="cg-site-wrapper">
	<!-- Load Bludit Plugins: Site Body Begin -->
	<?php Theme::plugins('siteBodyBegin') ?>
        <!-- main container -->
        <main id="cg-main-container">
            <div class="container">
			<!-- sidebar -->
			<div id="cg-sidebar">
                    <div id="cg-sidebar-wrapper" class="d-flex align-items-start flex-column h-100 w-100">
                        <!-- LOGO -->
                        <div id="cg-logo-cell" class="w-100">
                            <a class="cg-logo-link" href="<?php echo Theme::siteUrl() ?>">
                                <img src="<?php echo ($site->logo()?$site->logo():Theme::src('images/logo.png')) ?>" class="cg-logo" alt="cg" />
                            </a>
                        </div>
                        <!-- MENU CONTAINER -->
                        <div id="cg-sidebar-cell" class="w-200">
                            <!-- MENU -->
                            <nav id="cg-main-menu" class="menu-main-menu-container">
							<!-- TEXT AREA -->
                            </nav>
                        </div>
                        <!-- SOCIAL MEDIA ICONS -->
                        <div id="cg-social-cell" class="mt-auto w-100">
                            <div id="cg-social-inner">
                                <ul class="cg-social-icons">
                                    <li><a href="http://github.com/"><i class="fa fa-github"></i></a></li>
                                    <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="mailto:cagatay@guley.com.tr"><i class="fa fa-envelope"></i></a></li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
        <?php
            if ($WHERE_AM_I == 'page') {
                include(THEME_DIR.'php/page.php');
            } else {
                include(THEME_DIR.'php/home.php');
            }
        ?>
				
            </div>
        </main>

        <!-- site content
        ================================================== -->

				<!-- FOOTER -->
        <footer id="cg-footer">
            <div class="container">
                <div class="row cg-footer-wrapper">
                    <!-- FOOTER WIDGET 1 -->
                    <div class="col-12 col-lg-6 mb-4 mb-lg-0">
                        <h5 class="cg-title-with-border"><span>About Me</span></h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia, molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborum numquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium optio, eaque rerum! Provident similique accusantium nemo autem. </p>
                        <p><a href="about" class="btn btn-default">Read More</a></p>
                    </div>
                </div>
                <!-- CREDITS -->
                <div class="cg-footer-credits">
                    <p>
                        <?php echo $site->footer() ?>
                    </p>
                </div>
            </div>
        </footer>
    </div>
<!-- GO TO TOP BUTTON -->
    <a id="cg-gototop" href="#"><i class="fa fa-chevron-up"></i></a>

		<!-- Scripts -->
			<?php echo Theme::js('assets/js/jquery-3.3.1.min.js') ?>
			<?php echo Theme::js('assets/js/bootstrap.min.js') ?>
			<?php echo Theme::js('assets/js/salvattore.min.js') ?>
			<?php echo Theme::js('assets/js/slick.min.js') ?>
			<?php echo Theme::js('assets/js/panel.js') ?>
			<?php echo Theme::js('assets/js/reading-position-indicator.js') ?>
			<?php echo Theme::js('assets/js/custom.js') ?>
			    <!-- POST SLIDER -->
    <script>
        (function($) {
            "use strict";
            $(document).ready(function() {
                $('#cg-post-slider').slick({
                    autoplay: true,
                    autoplaySpeed: 5000,
                    slidesToScroll: 1,
                    adaptiveHeight: true,
                    slidesToShow: 1,
                    arrows: true,
                    dots: false,
                    fade: true
                });
            });
            $(window).on('load', function() {
                $('#cg-post-slider').css('opacity', '1');
                $('#cg-post-slider').parent().removeClass('cg-bg-loader');
            });
        })(jQuery);
    </script>
    <!-- POST CAROUSEL -->
    <script>
        (function($) {
            "use strict";
            $(document).ready(function() {
                $('#cg-post-carousel').slick({
                    infinite: false,
                    slidesToScroll: 1,
                    arrows: true,
                    dots: false,
                    slidesToShow: 3,
                    responsive: [{
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 2
                        }
                    }, {
                        breakpoint: 576,
                        settings: {
                            slidesToShow: 1
                        }
                    }]

                });
                $('#cg-post-carousel').css('opacity', '1');
            });
        })(jQuery);
    </script>


	<!-- Load Bludit Plugins: Site Body End -->
	<?php Theme::plugins('siteBodyEnd') ?>

	</body>
</html>