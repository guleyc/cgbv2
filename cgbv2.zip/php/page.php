<?php Theme::plugins('pageBegin') ?>
<!-- PAGE TITLE -->
<div class="cg-page-title">
	<h1><span><?php echo $page->title() ?></span></h1>
	<div class="cg-page-title-meta">
		<div class="cg-author-meta">
			<a class="author-meta" href="about">Cagatay Guley</a>
		</div>
		<div class="cg-date-meta"><?php if ($page->published()): ?><?php echo $page->date() ?><?php endif ?></div>
	</div>
</div>
<!-- POST CONTENT -->
<div class="cg-page-content">
	<?php echo $page->content() ?>
	<div class="clearfix"></div>
</div>
<?php Theme::plugins('pageEnd') ?>
