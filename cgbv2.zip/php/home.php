<?php foreach ($content as $page): ?>
<div class="card card-horizontal">
	<div class="card-body">
		<div class="card-horizontal-left">
			<h3 class="card-title"><a href="<?php echo $page->permalink() ?>"><?php echo $page->title() ?></a></h3>
			<div class="card-excerpt">
				<p><?php echo $page->contentBreak() ?></p>
				<?php if ($page->readMore()): ?><a href="<?php echo $page->permalink() ?>"><?php echo ('read more') ?></a><?php endif; ?>
			</div>
		</div>
		<?php if ($page->coverImage()): ?>
		<div class="card-horizontal-right" data-img="<?php echo $page->thumbCoverImage() ?>" srcset="<?php echo $page->coverImage() ?> 1x" alt="<?php echo $page->title() ?>">
			<a class="card-featured-img" href="<?php echo $page->permalink() ?>"></a>
		</div>
	<?php endif ?>
	</div>
</div>
<?php endforeach ?>